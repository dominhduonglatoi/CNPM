﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace QLBANHOA
{
    public partial class frm_DE_BaoCao : DevExpress.XtraReports.UI.XtraReport
    {
        public frm_DE_BaoCao()
        {
            InitializeComponent();
        }

    }
}
